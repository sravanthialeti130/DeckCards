package DeckProject;

import java.util.Comparator;
public class CardComparator implements Comparator<Card> {
    @Override
    public int compare(Card c1, Card c2) {
        // Compare by color first
        int color1 = getColor(c1.getSuit());
        int color2 = getColor(c2.getSuit());
        if (color1 != color2) {
            return Integer.compare(color1, color2);
        }

        // Compare by suit within the same color
        int suitComparison = c1.getSuit().compareTo(c2.getSuit());
        if (suitComparison != 0) {
            return suitComparison;
        }

        // Compare by rank
        return c1.getRank().compareTo(c2.getRank());
    }

    private int getColor(Suit suit) {
        switch (suit) {
            case Suit.HEART:
            case Suit.DIAMOND:
                return 1; // Red
            case Suit.SPADE:
            case Suit.CLUB:
                return 0; // Black
            default:
                throw new IllegalArgumentException("Unknown suit: " + suit);
        }
    }
}
