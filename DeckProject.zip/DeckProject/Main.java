package DeckProject;

import java.util.Collections;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Deck deck = new Deck();

        // Draw 20 random cards
        List<Card> drawnCards = deck.drawMultipleCards(20);

        // Print drawn cards before sorting
        System.out.println("Drawn cards before sorting:");
        for (Card card : drawnCards) {
            System.out.println(card);
        }

        // Sort the drawn cards
        Collections.sort(drawnCards, new CardComparator());

        // Print drawn cards after sorting
        System.out.println("\nDrawn cards after sorting:");
        for (Card card : drawnCards) {
            System.out.println(card);
        }
    }
}
