package DeckProject;

public enum Suit {
    SPADE, CLUB, HEART, DIAMOND
}
